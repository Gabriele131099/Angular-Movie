export const environment = {
  firebase: {
    projectId: 'hero-fa336',
    appId: '1:871783151976:web:9b27f4fc491ad6753d3edd',
    databaseURL: 'https://hero-fa336-default-rtdb.firebaseio.com',
    storageBucket: 'hero-fa336.appspot.com',
    apiKey: 'AIzaSyArqubtPU8r9EWPyva2KcDqhRdNnJzpjFg',
    authDomain: 'hero-fa336.firebaseapp.com',
    messagingSenderId: '871783151976',
    measurementId: 'G-RWM3WKEZ1N',
  },
  production: true
};
