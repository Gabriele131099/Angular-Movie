export const environment = {
  firebase: {
    projectId: 'hero3-257bf',
    appId: '1:669561094163:web:3091468a216ea18b323fe6',
    storageBucket: 'hero3-257bf.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyAhsoUn2rPqWO6KbkQWjmft8jiDLQU7waU',
    authDomain: 'hero3-257bf.firebaseapp.com',
    messagingSenderId: '669561094163',
    measurementId: 'G-PK59B4C9NW',
  },
  production: true
};
