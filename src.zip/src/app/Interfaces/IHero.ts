export interface IHero{
    id:number,
    name:string ,
}