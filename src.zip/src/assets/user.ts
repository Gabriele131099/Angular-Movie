export const USERS:any[]=[
    {
        id:0,
        username:'admin',
        password:'root'
    }
]