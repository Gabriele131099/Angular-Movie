
export const USERS:any[]=[
    {
        id:0,
        username:'admin',
        password:'root',
        email:'admin@gmail.com',
        date:'15-10-99',
        genre:'Other...'
    }
]